const form = document.getElementById("researchForm");
const promptEl = document.getElementById("prompt");
const modeEl = document.getElementById("mode");
const qualityEl = document.getElementById("quality");
const gradeLevelEl = document.getElementById("gradeLevel");
const citationStyleEl = document.getElementById("citationStyle");
const submitBtn = document.getElementById("submitBtn");
const chatLog = document.getElementById("chatLog");
const promptChips = document.getElementById("promptChips");
const sponsorFallbackEl = document.getElementById("sponsorFallback");

const appState = {
  config: null,
  gpt: {
    initialized: false,
    ready: false,
    slot: null
  }
};

function titleCase(value) {
  if (!value) {
    return "";
  }
  const text = String(value).replace(/_/g, " ");
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function addMessage(role, text, options = {}) {
  const wrapper = document.createElement("article");
  wrapper.className = `message ${role}`;

  const label = document.createElement("p");
  label.className = "message-label";
  label.textContent = role === "user" ? "You" : "Historia";

  const body = document.createElement("p");
  body.textContent = text;

  wrapper.append(label, body);

  if (options.blocked) {
    const tag = document.createElement("span");
    tag.className = "flag";
    tag.textContent = "Cheating request blocked";
    wrapper.append(tag);
  }

  if (Array.isArray(options.searchStrings) && options.searchStrings.length > 0) {
    const stringsWrap = document.createElement("div");
    stringsWrap.className = "search-strings";

    const heading = document.createElement("p");
    heading.className = "search-label";
    heading.textContent = "Search Strings";
    stringsWrap.append(heading);

    for (const value of options.searchStrings.slice(0, 5)) {
      const code = document.createElement("code");
      code.className = "string-item";
      code.textContent = value;
      stringsWrap.append(code);
    }

    wrapper.append(stringsWrap);
  }

  if (Array.isArray(options.sourceLinks) && options.sourceLinks.length > 0) {
    const linksWrap = document.createElement("div");
    linksWrap.className = "source-links";

    for (const item of options.sourceLinks) {
      if (!item || !item.url || !item.label) {
        continue;
      }

      const entry = document.createElement("a");
      entry.href = item.url;
      entry.target = "_blank";
      entry.rel = "noopener noreferrer";
      entry.className = "source-link";
      entry.textContent = item.label;

      const note = document.createElement("span");
      note.className = "source-note";
      note.textContent = item.note || "";

      const line = document.createElement("div");
      line.className = "source-line";
      line.append(entry, note);
      linksWrap.append(line);
    }

    if (linksWrap.children.length > 0) {
      wrapper.append(linksWrap);
    }
  }

  if (role === "assistant" && options.meta && typeof options.meta === "object") {
    const bits = [];

    if (options.meta.mode) {
      bits.push(`Mode: ${titleCase(options.meta.mode)}`);
    }
    if (options.meta.quality) {
      bits.push(`Depth: ${titleCase(options.meta.quality)}`);
    }
    if (options.meta.modelTier) {
      bits.push(`Model tier: ${titleCase(options.meta.modelTier)}`);
    }
    if (typeof options.meta.maxTokens === "number") {
      bits.push(`Token budget: ${options.meta.maxTokens}`);
    }
    if (options.meta.cached) {
      const age = typeof options.meta.cacheAgeSeconds === "number" ? ` (${options.meta.cacheAgeSeconds}s old)` : "";
      bits.push(`Cache hit${age}`);
    }
    if (options.meta.fallbackUsed) {
      bits.push("Fallback model used");
    }

    if (bits.length > 0) {
      const metaLine = document.createElement("p");
      metaLine.className = "meta-line";
      metaLine.textContent = bits.join(" | ");
      wrapper.append(metaLine);
    }

    if (options.meta.budgetNote) {
      const budgetTag = document.createElement("p");
      budgetTag.className = "budget-note";
      budgetTag.textContent = options.meta.budgetNote;
      wrapper.append(budgetTag);
    }
  }

  chatLog.append(wrapper);
  chatLog.scrollTop = chatLog.scrollHeight;
}

function setLoading(isLoading) {
  submitBtn.disabled = isLoading;
  submitBtn.textContent = isLoading ? "Researching..." : "Research with Historia";
}

function showSponsorStatus(text) {
  if (!sponsorFallbackEl) {
    return;
  }
  sponsorFallbackEl.textContent = text;
}

function initContextualAds() {
  if (appState.gpt.initialized) {
    return;
  }

  const ads = appState.config?.ads;
  if (!ads || !ads.enabled) {
    showSponsorStatus("Ads disabled. Enable ADS_ENABLED=true in .env to fund AI costs with contextual ads.");
    return;
  }

  if (ads.provider !== "gpt") {
    showSponsorStatus("Unsupported ad provider. Set ADS_PROVIDER=gpt for Google Publisher Tag.");
    return;
  }

  if (!ads.gptAdUnitPath) {
    showSponsorStatus("Missing ADS_GPT_AD_UNIT_PATH. Example: /1234567/historia_sidebar");
    return;
  }

  appState.gpt.initialized = true;

  window.googletag = window.googletag || { cmd: [] };

  const script = document.createElement("script");
  script.src = "https://securepubads.g.doubleclick.net/tag/js/gpt.js";
  script.async = true;
  script.onerror = () => {
    showSponsorStatus("Could not load ad script in this environment.");
  };
  document.head.append(script);

  window.googletag.cmd.push(() => {
    const slot = window.googletag.defineSlot(ads.gptAdUnitPath, [300, 250], "gptAdSlot");
    if (!slot) {
      showSponsorStatus("Ad slot definition failed. Check ADS_GPT_AD_UNIT_PATH.");
      return;
    }

    slot.addService(window.googletag.pubads());

    if (ads.nonPersonalized) {
      window.googletag.pubads().setRequestNonPersonalizedAds(1);
    }

    window.googletag.pubads().collapseEmptyDivs();
    window.googletag.enableServices();
    window.googletag.display("gptAdSlot");

    appState.gpt.slot = slot;
    appState.gpt.ready = true;
    showSponsorStatus("Contextual sponsorship active (non-personalized). ");
  });
}

function refreshAdTargeting(adContext) {
  if (!appState.gpt.ready || !window.googletag || !appState.gpt.slot) {
    return;
  }

  const context = adContext && typeof adContext === "object" ? adContext : {};

  window.googletag.cmd.push(() => {
    const pubads = window.googletag.pubads();
    pubads.clearTargeting();

    if (context.mode) {
      pubads.setTargeting("mode", [String(context.mode)]);
    }
    if (context.quality) {
      pubads.setTargeting("quality", [String(context.quality)]);
    }
    if (Array.isArray(context.keywords) && context.keywords.length > 0) {
      pubads.setTargeting("topic", context.keywords.slice(0, 5).map((item) => String(item)));
    }

    pubads.refresh([appState.gpt.slot]);
  });
}

async function loadAppConfig() {
  try {
    const response = await fetch("/api/config");
    if (!response.ok) {
      throw new Error("Config request failed");
    }
    appState.config = await response.json();

    const defaultQuality = appState.config?.defaults?.quality;
    if (defaultQuality && qualityEl.querySelector(`option[value="${defaultQuality}"]`)) {
      qualityEl.value = defaultQuality;
    }
  } catch {
    appState.config = null;
    showSponsorStatus("Config unavailable. Running with local defaults.");
  }

  initContextualAds();
}

async function submitPrompt(event) {
  event.preventDefault();
  const message = promptEl.value.trim();
  const mode = modeEl.value;
  const quality = qualityEl.value;
  const gradeLevel = gradeLevelEl.value;
  const citationStyle = citationStyleEl.value;

  if (!message) {
    return;
  }

  addMessage("user", message);
  promptEl.value = "";
  setLoading(true);

  try {
    const response = await fetch("/api/research", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        message,
        mode,
        quality,
        gradeLevel,
        citationStyle
      })
    });

    const data = await response.json();

    if (!response.ok) {
      addMessage("assistant", data.error || "Something went wrong. Please try again.", {
        searchStrings: Array.isArray(data.searchStrings) ? data.searchStrings : [],
        sourceLinks: Array.isArray(data.sourceLinks) ? data.sourceLinks : [],
        meta: data.meta
      });
      refreshAdTargeting(data.adContext || { mode, quality });
      return;
    }

    addMessage("assistant", data.reply || "No response received.", {
      blocked: Boolean(data.blocked),
      searchStrings: Array.isArray(data.searchStrings) ? data.searchStrings : [],
      sourceLinks: Array.isArray(data.sourceLinks) ? data.sourceLinks : [],
      meta: data.meta
    });

    refreshAdTargeting(data.adContext || { mode, quality });
  } catch {
    addMessage("assistant", "Network error. Check your server and try again.");
  } finally {
    setLoading(false);
  }
}

form.addEventListener("submit", submitPrompt);

promptChips.addEventListener("click", (event) => {
  const target = event.target;
  if (!(target instanceof HTMLButtonElement)) {
    return;
  }

  const prompt = target.dataset.prompt;
  if (!prompt) {
    return;
  }

  promptEl.value = prompt;

  if (target.dataset.mode && modeEl.querySelector(`option[value="${target.dataset.mode}"]`)) {
    modeEl.value = target.dataset.mode;
  }

  if (target.dataset.quality && qualityEl.querySelector(`option[value="${target.dataset.quality}"]`)) {
    qualityEl.value = target.dataset.quality;
  }

  promptEl.focus();
});

void loadAppConfig();
