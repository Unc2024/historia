import express from "express";

const CLAUDE_API_KEY = process.env.CLAUDE_API_KEY || "";

const CLAUDE_MODEL_FAST = process.env.CLAUDE_MODEL_FAST || "claude-3-5-haiku-latest";
const CLAUDE_MODEL_DEEP = process.env.CLAUDE_MODEL_DEEP || "claude-sonnet-4-20250514";
const CLAUDE_MODEL_ELITE = process.env.CLAUDE_MODEL_ELITE || "claude-opus-4-1-20250805";
const ENABLE_ELITE_UPGRADE = parseBool(process.env.ENABLE_ELITE_UPGRADE, false);

const DEFAULT_RESEARCH_QUALITY_RAW = process.env.DEFAULT_RESEARCH_QUALITY || "balanced";
const CACHE_TTL_SECONDS = clampNumber(parseIntSafe(process.env.CACHE_TTL_SECONDS, 21600), 60, 172800);
const CACHE_TTL_MS = CACHE_TTL_SECONDS * 1000;
const CACHE_MAX_ITEMS = clampNumber(parseIntSafe(process.env.CACHE_MAX_ITEMS, 500), 20, 3000);
const RESPONSE_CACHE = new Map();

const DAILY_CALL_LIMIT = clampNumber(parseIntSafe(process.env.DAILY_CALL_LIMIT, 800), 20, 100000);
const DAILY_DEEP_CALL_LIMIT = clampNumber(parseIntSafe(process.env.DAILY_DEEP_CALL_LIMIT, 250), 5, 100000);
const DAILY_ELITE_CALL_LIMIT = clampNumber(parseIntSafe(process.env.DAILY_ELITE_CALL_LIMIT, 30), 0, 100000);

const ADS_ENABLED = parseBool(process.env.ADS_ENABLED, false);
const ADS_PROVIDER = String(process.env.ADS_PROVIDER || "none").trim().toLowerCase();
const ADS_NON_PERSONALIZED = parseBool(process.env.ADS_NON_PERSONALIZED, true);
const ADS_GPT_AD_UNIT_PATH = String(process.env.ADS_GPT_AD_UNIT_PATH || "").trim();

const MAX_INPUT_CHARS = 3200;

const MODE_LABELS = {
  source_hunt: "Source Hunt",
  topic_explainer: "Topic Explainer",
  paper_planner: "Paper Planner",
  study_guide: "Study Guide Builder",
  source_evaluator: "Source Evaluator",
  citation_coach: "Citation Coach",
  quiz_practice: "Practice Quiz"
};

const QUALITY_LABELS = {
  quick: "Quick",
  balanced: "Balanced",
  deep: "Deep"
};

const GRADE_LABELS = {
  grade_9: "Grade 9",
  grade_10: "Grade 10",
  grade_11: "Grade 11",
  grade_12: "Grade 12",
  mixed_hs: "Mixed high school"
};

const CITATION_STYLE_LABELS = {
  none: "No citation style preference",
  mla: "MLA",
  apa: "APA",
  chicago: "Chicago"
};

const DEFAULT_RESEARCH_QUALITY = normalizeQuality(DEFAULT_RESEARCH_QUALITY_RAW);

const STOP_WORDS = new Set([
  "a",
  "about",
  "after",
  "all",
  "also",
  "an",
  "and",
  "are",
  "as",
  "at",
  "be",
  "because",
  "been",
  "before",
  "being",
  "between",
  "both",
  "but",
  "by",
  "can",
  "could",
  "did",
  "do",
  "does",
  "for",
  "from",
  "had",
  "has",
  "have",
  "help",
  "how",
  "i",
  "if",
  "in",
  "into",
  "is",
  "it",
  "its",
  "me",
  "more",
  "my",
  "of",
  "on",
  "or",
  "our",
  "please",
  "should",
  "so",
  "than",
  "that",
  "the",
  "their",
  "them",
  "there",
  "these",
  "they",
  "this",
  "to",
  "was",
  "we",
  "what",
  "when",
  "where",
  "which",
  "who",
  "why",
  "with",
  "would",
  "you",
  "your"
]);

const SYSTEM_PROMPT = `
You are Historia, an AI history and academic research coach for high school students.

Primary mission:
1) Help students learn deeply and accurately.
2) Teach ethical research, source evaluation, and planning.
3) Support school-approved help without doing graded work for the student.

Non-negotiable anti-cheating rules:
- Never write a student's submission text (no essay paragraphs, no thesis for submission, no final draft responses, no answers to graded worksheets/tests/quizzes).
- Never provide copy/paste-ready assignment answers.
- Refuse cheating requests briefly, then redirect to ethical help.

Allowed school-safe help:
- Research planning and source finding.
- Topic explanation and concept breakdowns.
- Study guides, practice questions, and self-check routines.
- Source reliability analysis (OPVL/CRAAP style reasoning).
- Citation guidance (MLA/APA/Chicago format coaching).

When suggesting sources:
- Prioritize peer-reviewed journals, university press books, .edu libraries, museum archives, and .gov historical repositories.
- Include for each source target:
  - Why it is relevant.
  - Exact search strings.
  - What evidence to extract.
  - A credibility note and what to verify.

Response requirements:
- Use clear section headers and bullet points.
- Include:
  1) Research Goal
  2) Search Strings
  3) Best Source Targets
  4) Student Work Plan
- Ask up to 3 clarifying questions only if critical context is missing.
- Keep tone practical and school-appropriate.
`.trim();

let DAILY_USAGE_STATE = {
  dayKey: "",
  calls: 0,
  deepCalls: 0,
  eliteCalls: 0,
  inputTokens: 0,
  outputTokens: 0
};

function sendJson(res, statusCode, payload) {
  res.status(statusCode).json(payload);
}

function parseIntSafe(value, fallback) {
  const parsed = Number.parseInt(String(value || ""), 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function clampNumber(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function parseBool(value, fallback) {
  if (typeof value !== "string") {
    return fallback;
  }
  const normalized = value.trim().toLowerCase();
  if (["1", "true", "yes", "on"].includes(normalized)) {
    return true;
  }
  if (["0", "false", "no", "off"].includes(normalized)) {
    return false;
  }
  return fallback;
}

function compactWhitespace(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function todayUtcKey() {
  return new Date().toISOString().slice(0, 10);
}

function getDailyUsageState() {
  const today = todayUtcKey();
  if (DAILY_USAGE_STATE.dayKey !== today) {
    DAILY_USAGE_STATE = {
      dayKey: today,
      calls: 0,
      deepCalls: 0,
      eliteCalls: 0,
      inputTokens: 0,
      outputTokens: 0
    };
  }
  return DAILY_USAGE_STATE;
}

function getBudgetSnapshot() {
  const state = getDailyUsageState();
  return {
    dayKey: state.dayKey,
    callsUsed: state.calls,
    callsLimit: DAILY_CALL_LIMIT,
    deepCallsUsed: state.deepCalls,
    deepCallsLimit: DAILY_DEEP_CALL_LIMIT,
    eliteCallsUsed: state.eliteCalls,
    eliteCallsLimit: DAILY_ELITE_CALL_LIMIT,
    inputTokensApprox: state.inputTokens,
    outputTokensApprox: state.outputTokens
  };
}

function normalizeMode(value) {
  if (typeof value !== "string") {
    return "source_hunt";
  }
  return Object.hasOwn(MODE_LABELS, value) ? value : "source_hunt";
}

function normalizeQuality(value) {
  if (typeof value !== "string") {
    return "balanced";
  }
  return Object.hasOwn(QUALITY_LABELS, value) ? value : "balanced";
}

function normalizeGradeLevel(value) {
  if (typeof value !== "string") {
    return "mixed_hs";
  }
  return Object.hasOwn(GRADE_LABELS, value) ? value : "mixed_hs";
}

function normalizeCitationStyle(value) {
  if (typeof value !== "string") {
    return "none";
  }
  return Object.hasOwn(CITATION_STYLE_LABELS, value) ? value : "none";
}

function scoreComplexity({ mode, message }) {
  const text = message.toLowerCase();
  let score = 1;

  if (message.length > 1200) {
    score += 3;
  } else if (message.length > 700) {
    score += 2;
  } else if (message.length > 320) {
    score += 1;
  }

  const advancedPatterns = [
    /\bcompare\b/,
    /\bcontrast\b/,
    /\bhistoriograph(y|ical)\b/,
    /\bprimary source\b/,
    /\bsecondary source\b/,
    /\bcounterargument\b/,
    /\bcausation\b/,
    /\bcontinuity\b/,
    /\bchange over time\b/,
    /\bmultiple perspectives\b/,
    /\binterpretation\b/,
    /\bevaluate\b/,
    /\bthesis\b/,
    /\bmethodology\b/
  ];

  for (const pattern of advancedPatterns) {
    if (pattern.test(text)) {
      score += 1;
    }
  }

  const questionCount = (message.match(/\?/g) || []).length;
  if (questionCount >= 2) {
    score += 1;
  }
  if (questionCount >= 4) {
    score += 1;
  }

  const modeBoost = {
    source_hunt: 2,
    topic_explainer: 1,
    paper_planner: 2,
    study_guide: 1,
    source_evaluator: 2,
    citation_coach: 1,
    quiz_practice: 1
  };
  score += modeBoost[mode] || 0;

  return clampNumber(score, 1, 10);
}

function modelTier(model) {
  const value = String(model || "").toLowerCase();
  if (value.includes("opus")) {
    return "elite";
  }
  if (value.includes("sonnet")) {
    return "deep";
  }
  if (value.includes("haiku")) {
    return "fast";
  }
  return "custom";
}

function selectModel({ quality, complexityScore, mode }) {
  if (quality === "quick") {
    return CLAUDE_MODEL_FAST;
  }

  if (quality === "deep") {
    if (ENABLE_ELITE_UPGRADE && complexityScore >= 9 && ["source_hunt", "topic_explainer"].includes(mode)) {
      return CLAUDE_MODEL_ELITE;
    }
    return CLAUDE_MODEL_DEEP;
  }

  if (complexityScore >= 8) {
    return CLAUDE_MODEL_DEEP;
  }

  if (complexityScore >= 6 && mode === "source_hunt") {
    return CLAUDE_MODEL_DEEP;
  }

  return CLAUDE_MODEL_FAST;
}

function applyBudgetPolicy(candidateModel) {
  const state = getDailyUsageState();
  if (state.calls >= DAILY_CALL_LIMIT) {
    return {
      blocked: true,
      budgetNote: "Daily request budget reached. Try again tomorrow or use cached repeated prompts."
    };
  }

  const tier = modelTier(candidateModel);
  let model = candidateModel;
  let budgetNote = "";

  if (tier === "elite") {
    if (!ENABLE_ELITE_UPGRADE) {
      model = CLAUDE_MODEL_DEEP;
      budgetNote = "Elite model disabled by configuration, routed to deep model.";
    } else if (state.eliteCalls >= DAILY_ELITE_CALL_LIMIT) {
      model = CLAUDE_MODEL_DEEP;
      budgetNote = "Elite daily limit reached, routed to deep model.";
    }
  }

  const adjustedTier = modelTier(model);
  if (adjustedTier === "deep" && state.deepCalls >= DAILY_DEEP_CALL_LIMIT) {
    model = CLAUDE_MODEL_FAST;
    budgetNote = "Deep-model daily limit reached, routed to fast model.";
  }

  return { blocked: false, model, budgetNote };
}

function selectMaxTokens({ quality, mode, complexityScore }) {
  const modeBase = {
    source_hunt: 800,
    topic_explainer: 700,
    paper_planner: 860,
    study_guide: 720,
    source_evaluator: 760,
    citation_coach: 650,
    quiz_practice: 700
  };

  const qualityDelta = {
    quick: -260,
    balanced: 0,
    deep: 320
  };

  const base = modeBase[mode] || 740;
  const delta = qualityDelta[quality] || 0;
  const complexityDelta = complexityScore * 45;
  return clampNumber(base + delta + complexityDelta, 380, 1700);
}

function selectTemperature({ quality, mode }) {
  if (quality === "quick") {
    return mode === "quiz_practice" ? 0.35 : 0.18;
  }
  if (quality === "deep") {
    return mode === "quiz_practice" ? 0.45 : 0.28;
  }
  return mode === "quiz_practice" ? 0.4 : 0.22;
}

function looksLikeCheatingRequest(input) {
  const text = input.toLowerCase();
  const educationalExemptions = [
    /what is a thesis statement/,
    /how do i write (an|a) thesis statement/,
    /how should (a|an) (intro|introduction|conclusion) work/,
    /make me a practice quiz/,
    /help me understand/,
    /teach me/,
    /explain this topic/
  ];

  if (educationalExemptions.some((rule) => rule.test(text))) {
    return false;
  }

  const cheatingPatterns = [
    /\bwrite\b.{0,35}\b(my|the)\b.{0,35}\b(essay|paper|dbq|assignment|homework|paragraph|response)\b/,
    /\bdo\b.{0,25}\b(my|the)\b.{0,25}\b(homework|assignment|worksheet|quiz|test|exam)\b/,
    /\bcomplete\b.{0,25}\b(my|the)\b.{0,25}\b(assignment|paper|essay|dbq|worksheet)\b/,
    /\bgive me\b.{0,35}\b(final draft|full answer|exact answer|intro paragraph|body paragraph|conclusion paragraph)\b/,
    /\bmake it sound like i wrote it\b/,
    /\bcopy.?paste\b/,
    /\bjust the answer\b/,
    /\banswer these questions for me\b/,
    /\bwrite my thesis\b/,
    /\bsolve this test\b/
  ];

  return cheatingPatterns.some((rule) => rule.test(text));
}

function blockedReply() {
  return [
    "I can't help write or complete graded work for you.",
    "",
    "I can still help you get a strong result ethically:",
    "1) Share your topic and rubric so I can build a high-quality research plan.",
    "2) I can find strong source targets (JSTOR, .edu libraries, archives, museums).",
    "3) I can help you create your own outline, notes, and study workflow."
  ].join("\n");
}

function modeInstructions(mode) {
  if (mode === "source_hunt") {
    return [
      "Mode focus: Source Hunt.",
      "Return strong source strategies and exact places to search first.",
      "Provide multiple search strings and suggest both primary and secondary sources."
    ].join(" ");
  }

  if (mode === "topic_explainer") {
    return [
      "Mode focus: Topic Explainer.",
      "Use grade-appropriate explanations, key terms, and cause/effect logic.",
      "Include common misconceptions and how to avoid them."
    ].join(" ");
  }

  if (mode === "paper_planner") {
    return [
      "Mode focus: Paper Planner.",
      "Provide a timeline-based plan with milestones, checkpoints, and revision workflow.",
      "Do not draft paper text for submission."
    ].join(" ");
  }

  if (mode === "study_guide") {
    return [
      "Mode focus: Study Guide Builder.",
      "Create a compact guide with key terms, timeline anchors, and self-test prompts.",
      "Include spaced repetition suggestions."
    ].join(" ");
  }

  if (mode === "source_evaluator") {
    return [
      "Mode focus: Source Evaluator.",
      "Use reliability checks (origin, purpose, evidence quality, bias, and limitations).",
      "Clearly distinguish credible claims vs claims requiring verification."
    ].join(" ");
  }

  if (mode === "citation_coach") {
    return [
      "Mode focus: Citation Coach.",
      "Teach citation rules and show formatted examples from user-provided source details.",
      "Explain common citation mistakes to avoid."
    ].join(" ");
  }

  if (mode === "quiz_practice") {
    return [
      "Mode focus: Practice Quiz.",
      "Create practice questions with answer keys and brief explanations for learning.",
      "Questions must be new practice items, not answers to active graded tests."
    ].join(" ");
  }

  return "Mode focus: general history research coaching.";
}

function qualityInstructions(quality) {
  if (quality === "quick") {
    return "Be concise and high-signal. Minimize extra detail while preserving quality.";
  }
  if (quality === "deep") {
    return "Provide high-depth analysis with nuanced context, competing interpretations, and stronger source strategy.";
  }
  return "Provide practical depth with actionable detail and efficient structure.";
}

function gradeInstructions(gradeLevel) {
  if (gradeLevel === "grade_9" || gradeLevel === "grade_10") {
    return "Use clear, plain language suitable for early high school readers.";
  }
  if (gradeLevel === "grade_11" || gradeLevel === "grade_12") {
    return "Use rigorous but accessible language suitable for upper high school coursework.";
  }
  return "Target mixed high school reading level and include optional advanced notes.";
}

function citationInstructions(citationStyle) {
  if (citationStyle === "mla") {
    return "When citing examples, prefer MLA conventions unless user says otherwise.";
  }
  if (citationStyle === "apa") {
    return "When citing examples, prefer APA conventions unless user says otherwise.";
  }
  if (citationStyle === "chicago") {
    return "When citing examples, prefer Chicago conventions unless user says otherwise.";
  }
  return "Mention citation practices only when useful to the student's request.";
}

function buildUserPrompt({ mode, quality, gradeLevel, citationStyle, message, complexityScore, searchStrings }) {
  const modeLabel = MODE_LABELS[mode] || MODE_LABELS.source_hunt;
  const qualityLabel = QUALITY_LABELS[quality] || QUALITY_LABELS.balanced;
  const gradeLabel = GRADE_LABELS[gradeLevel] || GRADE_LABELS.mixed_hs;
  const citationLabel = CITATION_STYLE_LABELS[citationStyle] || CITATION_STYLE_LABELS.none;

  return [
    `Student request mode: ${modeLabel}`,
    `Requested depth: ${qualityLabel}`,
    `Grade level target: ${gradeLabel}`,
    `Citation style preference: ${citationLabel}`,
    `Estimated complexity score: ${complexityScore}/10`,
    "",
    modeInstructions(mode),
    qualityInstructions(quality),
    gradeInstructions(gradeLevel),
    citationInstructions(citationStyle),
    "",
    "Prebuilt search-string candidates from app:",
    ...searchStrings.map((item, index) => `${index + 1}) ${item}`),
    "",
    "Student message:",
    message,
    "",
    "Hard constraints:",
    "- Do not write any graded submission text.",
    "- Prioritize source-finding and learning support.",
    "- Explicitly mark what should be verified.",
    "",
    "Respond as Historia with ethical school-safe guidance only."
  ].join("\n");
}

function extractResearchTopic(message) {
  const lowered = String(message || "").toLowerCase();
  const stripped = lowered
    .replace(
      /\b(write|do|complete|finish|solve|answer|answers|final|draft|copy|paste|my|the|an|a|essay|paper|dbq|assignment|homework|worksheet|quiz|test|exam|paragraph|submission)\b/g,
      " "
    )
    .replace(/\s+/g, " ")
    .trim();

  return stripped || compactWhitespace(message);
}

function extractKeywords(message) {
  const words = extractResearchTopic(message)
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, " ")
    .split(/\s+/)
    .map((word) => word.trim())
    .filter((word) => word.length >= 3 && !STOP_WORDS.has(word));

  const score = new Map();
  for (const word of words) {
    score.set(word, (score.get(word) || 0) + 1);
  }

  return Array.from(score.entries())
    .sort((a, b) => b[1] - a[1])
    .map(([word]) => word)
    .slice(0, 8);
}

function buildSearchStrings(message, mode) {
  const topic = extractResearchTopic(message);
  const keywords = extractKeywords(topic);
  const top = keywords.slice(0, 4);
  const joined = top.join(" ").trim();
  const primary = joined || compactWhitespace(topic).slice(0, 140);

  const templates = [
    `${primary} historiography`,
    `${primary} primary sources archive`,
    `${primary} peer reviewed journal`,
    `${primary} site:.edu history`,
    `${primary} site:.gov archives`,
    `${primary} scholarly monograph`
  ];

  if (mode === "source_evaluator") {
    templates.push(`${primary} source reliability analysis`);
  }
  if (mode === "citation_coach") {
    templates.push(`${primary} citation format guide`);
  }
  if (mode === "quiz_practice") {
    templates.push(`${primary} key terms timeline`);
  }

  return Array.from(new Set(templates.map((item) => compactWhitespace(item)).filter(Boolean))).slice(0, 7);
}

function buildSourceLinks({ message, searchStrings }) {
  const query = encodeURIComponent(searchStrings[0] || message.slice(0, 180));
  return [
    {
      label: "JSTOR",
      url: `https://www.jstor.org/action/doBasicSearch?Query=${query}`,
      note: "Peer-reviewed history journals and books."
    },
    {
      label: "Project MUSE",
      url: `https://muse.jhu.edu/search?action=search&query=${query}`,
      note: "Humanities journals and scholarly books."
    },
    {
      label: "Google Scholar",
      url: `https://scholar.google.com/scholar?q=${query}`,
      note: "Academic papers and citation trails."
    },
    {
      label: "WorldCat",
      url: `https://search.worldcat.org/search?q=${query}`,
      note: "Find academic books in nearby libraries."
    },
    {
      label: "Library of Congress",
      url: `https://www.loc.gov/search/?q=${query}`,
      note: "Primary documents, maps, and archives."
    },
    {
      label: "National Archives",
      url: `https://www.archives.gov/research/search?q=${query}`,
      note: "Government records and historical collections."
    },
    {
      label: ".edu Source Search",
      url: `https://www.google.com/search?q=site%3Aedu+${query}`,
      note: "University-hosted digital collections and libraries."
    }
  ];
}

function buildAdContext({ mode, quality, message }) {
  return {
    mode,
    quality,
    keywords: extractKeywords(message).slice(0, 6)
  };
}

function createCacheKey({ mode, quality, gradeLevel, citationStyle, message }) {
  const normalizedMessage = compactWhitespace(message.toLowerCase());
  return `${mode}::${quality}::${gradeLevel}::${citationStyle}::${normalizedMessage}`;
}

function getCachedResponse(cacheKey) {
  const record = RESPONSE_CACHE.get(cacheKey);
  if (!record) {
    return null;
  }
  if (record.expiresAt <= Date.now()) {
    RESPONSE_CACHE.delete(cacheKey);
    return null;
  }
  return record;
}

function setCachedResponse(cacheKey, value) {
  while (RESPONSE_CACHE.size >= CACHE_MAX_ITEMS) {
    const oldestKey = RESPONSE_CACHE.keys().next().value;
    if (!oldestKey) {
      break;
    }
    RESPONSE_CACHE.delete(oldestKey);
  }

  RESPONSE_CACHE.set(cacheKey, {
    value,
    createdAt: Date.now(),
    expiresAt: Date.now() + CACHE_TTL_MS
  });
}

function isRetryableClaudeError(error) {
  return [408, 429, 500, 502, 503, 504, 529].includes(error?.status);
}

function usageFromResponse(rawUsage) {
  if (!rawUsage || typeof rawUsage !== "object") {
    return {
      inputTokens: null,
      outputTokens: null,
      cacheReadInputTokens: null,
      cacheCreationInputTokens: null
    };
  }

  return {
    inputTokens: Number.isFinite(rawUsage.input_tokens) ? rawUsage.input_tokens : null,
    outputTokens: Number.isFinite(rawUsage.output_tokens) ? rawUsage.output_tokens : null,
    cacheReadInputTokens: Number.isFinite(rawUsage.cache_read_input_tokens)
      ? rawUsage.cache_read_input_tokens
      : null,
    cacheCreationInputTokens: Number.isFinite(rawUsage.cache_creation_input_tokens)
      ? rawUsage.cache_creation_input_tokens
      : null
  };
}

function estimateTokensFromText(text, minValue = 1) {
  const estimate = Math.ceil(String(text || "").length / 4);
  return Math.max(minValue, estimate);
}

function recordUsage({ model, usage, maxTokens, promptText, replyText }) {
  const state = getDailyUsageState();
  const tier = modelTier(model);

  state.calls += 1;
  if (tier === "deep" || tier === "elite") {
    state.deepCalls += 1;
  }
  if (tier === "elite") {
    state.eliteCalls += 1;
  }

  const inputEstimate = usage.inputTokens ?? estimateTokensFromText(promptText, 20);
  const outputEstimate = usage.outputTokens ?? clampNumber(estimateTokensFromText(replyText, 20), 20, maxTokens);

  state.inputTokens += inputEstimate;
  state.outputTokens += outputEstimate;

  return {
    inputTokens: inputEstimate,
    outputTokens: outputEstimate
  };
}

async function callClaude({ model, maxTokens, temperature, userPrompt }) {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": CLAUDE_API_KEY,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json"
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      temperature,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: "user",
          content: userPrompt
        }
      ]
    })
  });

  if (!response.ok) {
    const errorText = await response.text();
    const error = new Error(`Claude API error (${response.status}): ${errorText}`);
    error.status = response.status;
    throw error;
  }

  const data = await response.json();
  const replyText = Array.isArray(data.content)
    ? data.content
        .filter((item) => item && item.type === "text" && typeof item.text === "string")
        .map((item) => item.text.trim())
        .filter(Boolean)
        .join("\n\n")
    : "";

  return {
    reply: replyText || "I could not generate a response yet. Please try again.",
    usage: usageFromResponse(data.usage)
  };
}

async function generateResearchReply({ mode, quality, gradeLevel, citationStyle, message, searchStrings }) {
  const complexityScore = scoreComplexity({ mode, message });
  const requestedModel = selectModel({ quality, complexityScore, mode });
  const budgetDecision = applyBudgetPolicy(requestedModel);

  if (budgetDecision.blocked) {
    return {
      budgetBlocked: true,
      budgetMessage: budgetDecision.budgetNote,
      complexityScore
    };
  }

  const routedModel = budgetDecision.model;
  const maxTokens = selectMaxTokens({ quality, mode, complexityScore });
  const temperature = selectTemperature({ quality, mode });
  const userPrompt = buildUserPrompt({
    mode,
    quality,
    gradeLevel,
    citationStyle,
    message,
    complexityScore,
    searchStrings
  });

  try {
    const result = await callClaude({
      model: routedModel,
      maxTokens,
      temperature,
      userPrompt
    });

    const trackedUsage = recordUsage({
      model: routedModel,
      usage: result.usage,
      maxTokens,
      promptText: userPrompt,
      replyText: result.reply
    });

    return {
      budgetBlocked: false,
      reply: result.reply,
      model: routedModel,
      maxTokens,
      temperature,
      complexityScore,
      fallbackUsed: false,
      budgetNote: budgetDecision.budgetNote,
      usage: trackedUsage
    };
  } catch (error) {
    if (routedModel === CLAUDE_MODEL_FAST || !isRetryableClaudeError(error)) {
      throw error;
    }

    const fallbackDecision = applyBudgetPolicy(CLAUDE_MODEL_FAST);
    if (fallbackDecision.blocked) {
      return {
        budgetBlocked: true,
        budgetMessage: fallbackDecision.budgetNote,
        complexityScore
      };
    }

    const fallbackMaxTokens = clampNumber(Math.round(maxTokens * 0.78), 380, 1200);
    const fallbackTemperature = 0.18;
    const fallbackResult = await callClaude({
      model: fallbackDecision.model,
      maxTokens: fallbackMaxTokens,
      temperature: fallbackTemperature,
      userPrompt
    });

    const trackedUsage = recordUsage({
      model: fallbackDecision.model,
      usage: fallbackResult.usage,
      maxTokens: fallbackMaxTokens,
      promptText: userPrompt,
      replyText: fallbackResult.reply
    });

    const budgetNotes = [budgetDecision.budgetNote, fallbackDecision.budgetNote]
      .map((item) => item.trim())
      .filter(Boolean)
      .join(" ");

    return {
      budgetBlocked: false,
      reply: fallbackResult.reply,
      model: fallbackDecision.model,
      maxTokens: fallbackMaxTokens,
      temperature: fallbackTemperature,
      complexityScore,
      fallbackUsed: true,
      budgetNote: budgetNotes,
      usage: trackedUsage
    };
  }
}

function buildConfigPayload() {
  return {
    ads: {
      enabled: ADS_ENABLED,
      provider: ADS_PROVIDER,
      nonPersonalized: ADS_NON_PERSONALIZED,
      gptAdUnitPath: ADS_GPT_AD_UNIT_PATH
    },
    models: {
      fastDefault: CLAUDE_MODEL_FAST,
      deepDefault: CLAUDE_MODEL_DEEP,
      eliteDefault: CLAUDE_MODEL_ELITE,
      eliteUpgradeEnabled: ENABLE_ELITE_UPGRADE
    },
    defaults: {
      quality: DEFAULT_RESEARCH_QUALITY
    },
    limits: {
      cacheTtlSeconds: CACHE_TTL_SECONDS,
      cacheMaxItems: CACHE_MAX_ITEMS,
      dailyCallLimit: DAILY_CALL_LIMIT,
      dailyDeepCallLimit: DAILY_DEEP_CALL_LIMIT,
      dailyEliteCallLimit: DAILY_ELITE_CALL_LIMIT
    }
  };
}

async function handleResearch(req, res) {
  const payload = req.body && typeof req.body === "object" ? req.body : {};

  const mode = normalizeMode(payload.mode);
  const quality = normalizeQuality(payload.quality || DEFAULT_RESEARCH_QUALITY);
  const gradeLevel = normalizeGradeLevel(payload.gradeLevel);
  const citationStyle = normalizeCitationStyle(payload.citationStyle);
  const message = typeof payload.message === "string" ? payload.message.trim() : "";

  if (!message) {
    return sendJson(res, 400, { error: "Please enter a question or research goal." });
  }

  if (message.length > MAX_INPUT_CHARS) {
    return sendJson(res, 400, {
      error: `Message is too long. Keep it under ${MAX_INPUT_CHARS} characters.`
    });
  }

  const searchStrings = buildSearchStrings(message, mode);
  const sourceLinks = buildSourceLinks({ message, searchStrings });
  const adContext = buildAdContext({ mode, quality, message });

  if (looksLikeCheatingRequest(message)) {
    return sendJson(res, 200, {
      blocked: true,
      reply: blockedReply(),
      searchStrings,
      sourceLinks,
      adContext,
      meta: {
        mode,
        quality,
        gradeLevel,
        citationStyle,
        blockedByGuardrails: true,
        cached: false,
        budget: getBudgetSnapshot()
      }
    });
  }

  if (!CLAUDE_API_KEY) {
    return sendJson(res, 503, {
      error: "Claude API key not found. Add CLAUDE_API_KEY to your .env or shell environment."
    });
  }

  const cacheKey = createCacheKey({
    mode,
    quality,
    gradeLevel,
    citationStyle,
    message
  });

  const cached = getCachedResponse(cacheKey);
  if (cached) {
    return sendJson(res, 200, {
      blocked: false,
      reply: cached.value.reply,
      searchStrings,
      sourceLinks,
      adContext,
      meta: {
        ...cached.value.meta,
        cached: true,
        cacheAgeSeconds: Math.floor((Date.now() - cached.createdAt) / 1000),
        budget: getBudgetSnapshot()
      }
    });
  }

  try {
    const result = await generateResearchReply({
      mode,
      quality,
      gradeLevel,
      citationStyle,
      message,
      searchStrings
    });

    if (result.budgetBlocked) {
      return sendJson(res, 429, {
        error: result.budgetMessage,
        searchStrings,
        sourceLinks,
        adContext,
        meta: {
          mode,
          quality,
          gradeLevel,
          citationStyle,
          budgetBlocked: true,
          budget: getBudgetSnapshot()
        }
      });
    }

    const meta = {
      mode,
      quality,
      gradeLevel,
      citationStyle,
      model: result.model,
      modelTier: modelTier(result.model),
      maxTokens: result.maxTokens,
      temperature: result.temperature,
      complexityScore: result.complexityScore,
      fallbackUsed: result.fallbackUsed,
      budgetNote: result.budgetNote,
      usage: result.usage,
      cached: false,
      cacheTtlSeconds: CACHE_TTL_SECONDS,
      budget: getBudgetSnapshot()
    };

    setCachedResponse(cacheKey, {
      reply: result.reply,
      meta
    });

    return sendJson(res, 200, {
      blocked: false,
      reply: result.reply,
      searchStrings,
      sourceLinks,
      adContext,
      meta
    });
  } catch (error) {
    console.error(error);
    return sendJson(res, 502, {
      error: "Could not reach Claude API right now. Please try again shortly."
    });
  }
}

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));

app.use((error, _req, res, next) => {
  if (error?.type === "entity.too.large") {
    return sendJson(res, 413, { error: "Request body too large." });
  }
  if (error instanceof SyntaxError && "body" in error) {
    return sendJson(res, 400, { error: "Invalid JSON payload." });
  }
  return next(error);
});

app.get(["/", "/api", "/config", "/api/config"], (_req, res) => {
  return sendJson(res, 200, buildConfigPayload());
});

app.post(["/", "/api", "/research", "/api/research"], async (req, res) => {
  return handleResearch(req, res);
});

app.all("*", (_req, res) => {
  return sendJson(res, 405, { error: "Method Not Allowed" });
});

app.use((error, _req, res, _next) => {
  console.error(error);
  return sendJson(res, 500, { error: "Internal server error." });
});

export default app;
