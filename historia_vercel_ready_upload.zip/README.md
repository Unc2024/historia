# Historia

Historia is a high-school-focused AI research assistant with strict anti-cheating guardrails.

## Architecture (Vercel)

- Frontend: static files in `public/` (served directly by Vercel).
- Backend: Vercel Function in `api/index.js` (Express app for API routes only).
- API routes used by frontend:
- `GET /api/config`
- `POST /api/research`

`vercel.json` rewrites only `/api/*` to `/api`, so static routes are untouched.

## Environment Variables

Set these in `.env` locally and in Vercel Project Environment Variables:

- `CLAUDE_API_KEY`
- `CLAUDE_MODEL_FAST`
- `CLAUDE_MODEL_DEEP`
- `CLAUDE_MODEL_ELITE`
- `ENABLE_ELITE_UPGRADE`
- `DEFAULT_RESEARCH_QUALITY`
- `CACHE_TTL_SECONDS`
- `CACHE_MAX_ITEMS`
- `DAILY_CALL_LIMIT`
- `DAILY_DEEP_CALL_LIMIT`
- `DAILY_ELITE_CALL_LIMIT`
- `ADS_ENABLED`
- `ADS_PROVIDER`
- `ADS_NON_PERSONALIZED`
- `ADS_GPT_AD_UNIT_PATH`
- `PORT` (used only for local non-Vercel script)

## Local Development (Vercel runtime)

1. Install dependencies:

```bash
npm install
```

2. Install Vercel CLI:

```bash
npm i -g vercel
```

3. Login to Vercel:

```bash
vercel login
```

4. Create local env file:

```bash
cp .env.example .env
```

5. Run local Vercel dev server:

```bash
npm run dev
```

## Deploy

From the repo root:

```bash
vercel
```

Or connect the repository in the Vercel dashboard.

After deploy, confirm `CLAUDE_API_KEY` and the other variables above are set in Project Settings -> Environment Variables.

## Optional local-only server

A legacy local Node server file is kept as `server.local.js` and can be run with:

```bash
npm run dev:local
```
